import mongoose from 'mongoose';

// Define the schema for your Price model
const PriceSchema = new mongoose.Schema({
  name: { type: String, required: true },
  symbol: { type: String, required: true },
  png32: { type: String, required: true },
  rank: { type: Number, required: true },
  rate: { type: Number, required: true },
  allTimeHighUSD: { type: Number, required: true },
  circulatingSupply: { type: Number, required: true },
  totalSupply: { type: Number, required: true },
  maxSupply: { type: Number, required: true },
  volume: { type: Number, required: true },
  cap: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now },
});

// Ensure the model is only created once
const crypto_Price = mongoose.models.crypto_Price || mongoose.model('crypto_Price', PriceSchema);

export default crypto_Price;
