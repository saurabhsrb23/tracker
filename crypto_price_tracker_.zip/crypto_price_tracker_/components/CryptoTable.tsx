import { fetchCryptoStart } from '@/redux/slices/cryptoSlice';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

const CryptoComponent = () => {
  const dispatch = useDispatch<any>();
  const { data, status, error } = useSelector((state:any) => state.crypto);

  useEffect(() => {
    const fetchCryptoData = async () => {
      dispatch(fetchCryptoStart());
      try {
        const response = await fetch('/api/fetchLiveCoinWatch'); // Adjust API endpoint as needed
        const result = await response.json();
        dispatch(fetchCryptoSuccess(result.data));
      } catch (err) {
        dispatch(fetchCryptoFailure('Failed to fetch crypto data'));
      }
    };

    fetchCryptoData();

    // Optionally clear data on component unmount
    return () => {
      dispatch(clearCryptoData());
    };
  }, [dispatch]);

  if (status === 'loading') return <div>Loading...</div>;
  if (status === 'failed') return <div>Error: {error}</div>;

  return (
    <div>
      {data.map((crypto:any) => (
        <div key={crypto.symbol}>
          <h2>{crypto.name} ({crypto.symbol})</h2>
          <p>Rank: {crypto.rank}</p>
          <p>Rate: ${crypto.rate}</p>
          <p>Volume: ${crypto.volume}</p>
          <p>Market Cap: ${crypto.cap}</p>
          <p>All-Time High: ${crypto.allTimeHighUSD}</p>
        </div>
      ))}
    </div>
  );
};

export default CryptoComponent;
function fetchCryptoSuccess(data: any): any {
  throw new Error('Function not implemented.');
}

function fetchCryptoFailure(arg0: string): any {
  throw new Error('Function not implemented.');
}

function clearCryptoData(): any {
  throw new Error('Function not implemented.');
}

