import { CoinData } from '@/interface/liveCoinInterface';
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface CryptoState {
  data: Array<CoinData>;
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
}

const initialState: CryptoState = {
  data: [],
  status: 'idle',
  error: null,
};

const cryptoSlice = createSlice({
  name: 'crypto',
  initialState,
  reducers: {
    fetchCryptoStart(state) {
      state.status = 'loading';
    },
    fetchCryptoSuccess(state, action: PayloadAction<typeof initialState.data>) {
      state.data = action.payload;
      state.status = 'succeeded';
      state.error = null;
    },
    fetchCryptoFailure(state, action: PayloadAction<string>) {
      state.status = 'failed';
      state.error = action.payload;
    },
    clearCryptoData(state) {
      state.data = [];
      state.status = 'idle';
      state.error = null;
    },
  },
});

// Export actions
export const { fetchCryptoStart, fetchCryptoSuccess, fetchCryptoFailure, clearCryptoData } = cryptoSlice.actions;

// Export the reducer
export default cryptoSlice.reducer;
