import { configureStore } from '@reduxjs/toolkit';
import { createWrapper } from 'next-redux-wrapper';
import cryptoReducer from './slices/cryptoSlice';

const makeStore = () =>
  configureStore({
    reducer: {
      crypto: cryptoReducer,
    },
    devTools: process.env.NODE_ENV !== 'production',
  });

export const wrapper = createWrapper(makeStore);