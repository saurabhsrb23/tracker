
import PriceTable from "@/components/CryptoTable";
import DefaultLayout from "@/layouts/default";

export default function IndexPage() {
  return (
    <DefaultLayout>
    <div style={{border:'1px solid red'}}>
    <h1>Real-time Price Data</h1>
      <PriceTable />
    </div>
    </DefaultLayout>
  );
}
