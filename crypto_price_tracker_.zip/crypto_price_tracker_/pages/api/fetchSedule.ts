import { NextApiRequest, NextApiResponse } from 'next';
import { schedule } from 'node-cron';
import fetchPrices from './fetchPrices'; // Ensure correct path

let cronJobStarted = false;

const startCronJob = () => {
  if (!cronJobStarted) {
    schedule('*/5 * * * * *', async () => {
      console.log('Cron job triggered'); // Debug log
      try {
        await fetchPrices();
        console.log('Prices fetched and stored successfully');
      } catch (error) {
        console.error('Failed to fetch and store prices:', error);
      }
    });

    cronJobStarted = true;
  }
};

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  startCronJob();
  res.status(200).json({ message: 'Cron job started' });
}
