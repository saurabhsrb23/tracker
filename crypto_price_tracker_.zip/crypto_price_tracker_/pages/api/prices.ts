import type { NextApiRequest, NextApiResponse } from 'next';
import connectToDatabase from '@/utils/dbConnect';
import Price from '@/Models/CryptoModal';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  await connectToDatabase();

  try {
    const prices = await Price.find().sort({ timestamp: -1 }).limit(20);
    console.log(prices);
    
    res.status(200).json(prices);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch prices' });
  }
}
