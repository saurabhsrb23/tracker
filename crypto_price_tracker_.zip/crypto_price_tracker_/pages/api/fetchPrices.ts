import axios from 'axios';
import connectToDatabase from '@/utils/dbConnect';
import Price from '@/Models/CryptoModal';
import { CoinData } from '@/interface/liveCoinInterface';

interface LiveCoinWatchResponse {
  data: CoinData[];
}

const API_URL = 'https://api.livecoinwatch.com/coins/list';
const API_KEY = process.env.API_KEY || '863ddfa4-3673-44bc-af2b-07e3936c1edf';

const fetchPrices = async () => {

  console.log('callingggggggggggggggggg');
  
  await connectToDatabase();
console.log('working');

  try {
    const response = await axios.post<LiveCoinWatchResponse>(
      API_URL,
      {
        currency: 'USD',
        sort: 'rank',
        order: 'ascending',
        offset: 0,
        limit: 10,
        meta: true,
      },
      {
        headers: {
          'content-type': 'application/json',
          'x-api-key': API_KEY,
        },
      }
    );
    console.log('working 1',response);

    const prices = response.data.data.map((coin) => ({
      name: coin.name,
      symbol: coin.symbol,
      rank: coin.rank,
      rate: coin.rate,
      allTimeHighUSD: coin.allTimeHighUSD,
      circulatingSupply: coin.circulatingSupply,
      totalSupply: coin.totalSupply,
      maxSupply: coin.maxSupply,
      volume: coin.volume,
      cap: coin.cap,
      timestamp: new Date(),
    }));

    await Price.insertMany(prices);
    console.log('Prices fetched and stored successfully');
  } catch (error) {
    console.error('Failed to fetch prices:', error);
    throw error;
  }
};

export default fetchPrices;
