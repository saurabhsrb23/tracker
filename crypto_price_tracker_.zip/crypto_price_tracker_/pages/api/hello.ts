import fetchPrices from './fetchPrices';

(async () => {
  try {
    await fetchPrices();
    console.log('Prices fetched and stored successfully');
  } catch (error) {
    console.error('Failed to fetch and store prices:', error);
  }
})();
