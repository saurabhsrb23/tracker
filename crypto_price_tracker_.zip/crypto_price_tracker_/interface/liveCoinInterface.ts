export interface CoinData {
  name: string;
  symbol: string;
  rank: number;
  rate: number;
  allTimeHighUSD: number;
  circulatingSupply: number;
  totalSupply: number;
  maxSupply: number;
  volume: number;
  cap: number;
}