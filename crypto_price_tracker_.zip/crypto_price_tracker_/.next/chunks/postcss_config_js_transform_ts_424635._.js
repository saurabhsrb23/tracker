(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/postcss_config_js_transform_ts_424635._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/postcss_config_js_transform_ts_424635._.js",
  "chunks": [
    "chunks/node_modules_b91ee9._.js",
    "chunks/fc95d_Documents_Next_js_stock_crypto-price-tracker_crypto_price_tracker_498cf4._.js"
  ],
  "source": "dynamic"
});
