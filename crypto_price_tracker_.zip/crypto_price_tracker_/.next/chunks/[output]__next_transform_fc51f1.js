(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "chunks/[output]__next_transform_fc51f1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "chunks/[output]__next_transform_fc51f1.js",
  "chunks": [
    "chunks/[turbopack-node]__1ff071._.js",
    "chunks/postcss_config_js_transform_ts_656abd._.js"
  ],
  "source": "entry"
});
