module.exports = {

"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>Document
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/document.js [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
function Document() {
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Html"], {
        lang: "en",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Head"], {}, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                lineNumber: 6,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("body", {
                className: "min-h-screen bg-background font-sans antialiased",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Main"], {}, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                        lineNumber: 8,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["NextScript"], {}, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                        lineNumber: 9,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}

})()),
"[next]/internal/font/google/inter_b35c0a41.module.css [ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "inter_b35c0a41-module__Y0D1la__className",
  "variable": "inter_b35c0a41-module__Y0D1la__variable",
});

})()),
"[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.module.css [ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__Inter_b35c0a', '__Inter_Fallback_b35c0a'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[next]/internal/font/google/fira_code_b79a8a20.module.css [ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "fira_code_b79a8a20-module__-fm2dq__className",
  "variable": "fira_code_b79a8a20-module__-fm2dq__variable",
});

})()),
"[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.module.css [ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__Fira_Code_b79a8a', '__Fira_Code_Fallback_b79a8a'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
;
;
;
;

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$fonts$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript) <export default as fontSans>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "fontSans": ()=>__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript) <export default as fontMono>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "fontMono": ()=>__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__,
    "fonts": ()=>fonts
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__ = __turbopack_external_import__("@nextui-org/system");
var __TURBOPACK__commonjs__external__next$2d$themes__ = __turbopack_external_require__("next-themes", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$fonts$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontSans$3e$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript) <export default as fontSans>");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontMono$3e$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript) <export default as fontMono>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/store.ts [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__
]);
[__TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
function App({ Component, pageProps }) {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__["NextUIProvider"], {
        navigate: router.push,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__commonjs__external__next$2d$themes__["ThemeProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(Component, {
                ...pageProps
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
                lineNumber: 17,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
            lineNumber: 16,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
const fonts = {
    sans: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontSans$3e$__["fontSans"].style.fontFamily,
    mono: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontMono$3e$__["fontMono"].style.fontFamily
};
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["wrapper"].withRedux(App);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/store.ts [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "setPrices": ()=>setPrices,
    "wrapper": ()=>wrapper
});
var __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__ = __turbopack_external_import__("@reduxjs/toolkit");
var __TURBOPACK__commonjs__external__next$2d$redux$2d$wrapper__ = __turbopack_external_require__("next-redux-wrapper", true);
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__
]);
[__TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
const initialState = {
    prices: []
};
const priceSlice = (0, __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__["createSlice"])({
    name: 'price',
    initialState,
    reducers: {
        setPrices (state, action) {
            state.prices = action.payload;
        }
    }
});
const { setPrices } = priceSlice.actions;
const makeStore = ()=>(0, __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__["configureStore"])({
        reducer: {
            price: priceSlice.reducer
        }
    });
const store = makeStore();
const wrapper = (0, __TURBOPACK__commonjs__external__next$2d$redux$2d$wrapper__["createWrapper"])(makeStore);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__commonjs__external__react__ = __turbopack_external_require__("react", true);
var __TURBOPACK__esm__external__react$2d$redux__ = __turbopack_external_import__("react-redux");
var __TURBOPACK__esm__external__axios__ = __turbopack_external_import__("axios");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/store.ts [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__react$2d$redux__,
    __TURBOPACK__esm__external__axios__,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__esm__external__react$2d$redux__, __TURBOPACK__esm__external__axios__, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
const PriceTable = ()=>{
    const dispatch = (0, __TURBOPACK__esm__external__react$2d$redux__["useDispatch"])();
    const prices = (0, __TURBOPACK__esm__external__react$2d$redux__["useSelector"])((state)=>state.price.prices);
    (0, __TURBOPACK__commonjs__external__react__["useEffect"])(()=>{
        const fetchPrices = async ()=>{
            const { data } = await __TURBOPACK__esm__external__axios__["default"].get('/api/prices');
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["setPrices"])(data));
        };
        fetchPrices();
        const interval = setInterval(fetchPrices, 5000);
        return ()=>clearInterval(interval);
    }, [
        dispatch
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("table", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("thead", {
                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("tr", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("th", {
                            children: "Symbol"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                            lineNumber: 28,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("th", {
                            children: "Price"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                            lineNumber: 29,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("th", {
                            children: "Timestamp"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                            lineNumber: 30,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("tbody", {
                children: prices.map((price)=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("tr", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("td", {
                                children: price.symbol
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                                lineNumber: 36,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("td", {
                                children: price.price
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                                lineNumber: 37,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("td", {
                                children: new Date(price.timestamp).toLocaleString()
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                                lineNumber: 38,
                                columnNumber: 13
                            }, this)
                        ]
                    }, price.timestamp.toString(), true, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                        lineNumber: 35,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
};
const __TURBOPACK__default__export__ = PriceTable;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/site.ts [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "siteConfig": ()=>siteConfig
});
const siteConfig = {
    name: "Next.js + NextUI",
    description: "Make beautiful websites regardless of your design experience.",
    navItems: [
        {
            label: "Home",
            href: "/"
        },
        {
            label: "Docs",
            href: "/docs"
        },
        {
            label: "Pricing",
            href: "/pricing"
        },
        {
            label: "Blog",
            href: "/blog"
        },
        {
            label: "About",
            href: "/about"
        }
    ],
    navMenuItems: [
        {
            label: "Profile",
            href: "/profile"
        },
        {
            label: "Dashboard",
            href: "/dashboard"
        },
        {
            label: "Projects",
            href: "/projects"
        },
        {
            label: "Team",
            href: "/team"
        },
        {
            label: "Calendar",
            href: "/calendar"
        },
        {
            label: "Settings",
            href: "/settings"
        },
        {
            label: "Help & Feedback",
            href: "/help-feedback"
        },
        {
            label: "Logout",
            href: "/logout"
        }
    ],
    links: {
        github: "https://github.com/nextui-org/nextui",
        twitter: "https://twitter.com/getnextui",
        docs: "https://nextui-docs-v2.vercel.app",
        discord: "https://discord.gg/9b6yyZKmH4",
        sponsor: "https://patreon.com/jrgarciadev"
    }
};

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "Head": ()=>Head
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__commonjs__external__next$2f$head$2e$js__ = __turbopack_external_require__("next/head.js", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/site.ts [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const Head = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__commonjs__external__next$2f$head$2e$js__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("title", {
                children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].name
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("meta", {
                content: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].name,
                property: "og:title"
            }, "title", false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("meta", {
                content: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].description,
                property: "og:description"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
                lineNumber: 11,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("meta", {
                content: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].description,
                name: "description"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
                lineNumber: 12,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("meta", {
                content: "viewport-fit=cover, width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0",
                name: "viewport"
            }, "viewport", false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("link", {
                href: "/favicon.ico",
                rel: "icon"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
};

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "DiscordIcon": ()=>DiscordIcon,
    "GithubIcon": ()=>GithubIcon,
    "HeartFilledIcon": ()=>HeartFilledIcon,
    "Logo": ()=>Logo,
    "MoonFilledIcon": ()=>MoonFilledIcon,
    "NextUILogo": ()=>NextUILogo,
    "SearchIcon": ()=>SearchIcon,
    "SunFilledIcon": ()=>SunFilledIcon,
    "TwitterIcon": ()=>TwitterIcon
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
"__TURBOPACK__ecmascript__hoisting__location__";
;
const Logo = ({ size = 36, height, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        fill: "none",
        height: size || height,
        viewBox: "0 0 32 32",
        width: size || height,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
            clipRule: "evenodd",
            d: "M17.6482 10.1305L15.8785 7.02583L7.02979 22.5499H10.5278L17.6482 10.1305ZM19.8798 14.0457L18.11 17.1983L19.394 19.4511H16.8453L15.1056 22.5499H24.7272L19.8798 14.0457Z",
            fill: "currentColor",
            fillRule: "evenodd"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 17,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 10,
        columnNumber: 3
    }, this);
const DiscordIcon = ({ size = 24, width, height, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        height: size || height,
        viewBox: "0 0 24 24",
        width: size || width,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
            d: "M14.82 4.26a10.14 10.14 0 0 0-.53 1.1 14.66 14.66 0 0 0-4.58 0 10.14 10.14 0 0 0-.53-1.1 16 16 0 0 0-4.13 1.3 17.33 17.33 0 0 0-3 11.59 16.6 16.6 0 0 0 5.07 2.59A12.89 12.89 0 0 0 8.23 18a9.65 9.65 0 0 1-1.71-.83 3.39 3.39 0 0 0 .42-.33 11.66 11.66 0 0 0 10.12 0q.21.18.42.33a10.84 10.84 0 0 1-1.71.84 12.41 12.41 0 0 0 1.08 1.78 16.44 16.44 0 0 0 5.06-2.59 17.22 17.22 0 0 0-3-11.59 16.09 16.09 0 0 0-4.09-1.35zM8.68 14.81a1.94 1.94 0 0 1-1.8-2 1.93 1.93 0 0 1 1.8-2 1.93 1.93 0 0 1 1.8 2 1.93 1.93 0 0 1-1.8 2zm6.64 0a1.94 1.94 0 0 1-1.8-2 1.93 1.93 0 0 1 1.8-2 1.92 1.92 0 0 1 1.8 2 1.92 1.92 0 0 1-1.8 2z",
            fill: "currentColor"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 39,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
};
const TwitterIcon = ({ size = 24, width, height, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        height: size || height,
        viewBox: "0 0 24 24",
        width: size || width,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
            d: "M19.633 7.997c.013.175.013.349.013.523 0 5.325-4.053 11.461-11.46 11.461-2.282 0-4.402-.661-6.186-1.809.324.037.636.05.973.05a8.07 8.07 0 0 0 5.001-1.721 4.036 4.036 0 0 1-3.767-2.793c.249.037.499.062.761.062.361 0 .724-.05 1.061-.137a4.027 4.027 0 0 1-3.23-3.953v-.05c.537.299 1.16.486 1.82.511a4.022 4.022 0 0 1-1.796-3.354c0-.748.199-1.434.548-2.032a11.457 11.457 0 0 0 8.306 4.215c-.062-.3-.1-.611-.1-.923a4.026 4.026 0 0 1 4.028-4.028c1.16 0 2.207.486 2.943 1.272a7.957 7.957 0 0 0 2.556-.973 4.02 4.02 0 0 1-1.771 2.22 8.073 8.073 0 0 0 2.319-.624 8.645 8.645 0 0 1-2.019 2.083z",
            fill: "currentColor"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 60,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
};
const GithubIcon = ({ size = 24, width, height, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        height: size || height,
        viewBox: "0 0 24 24",
        width: size || width,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
            clipRule: "evenodd",
            d: "M12.026 2c-5.509 0-9.974 4.465-9.974 9.974 0 4.406 2.857 8.145 6.821 9.465.499.09.679-.217.679-.481 0-.237-.008-.865-.011-1.696-2.775.602-3.361-1.338-3.361-1.338-.452-1.152-1.107-1.459-1.107-1.459-.905-.619.069-.605.069-.605 1.002.07 1.527 1.028 1.527 1.028.89 1.524 2.336 1.084 2.902.829.091-.645.351-1.085.635-1.334-2.214-.251-4.542-1.107-4.542-4.93 0-1.087.389-1.979 1.024-2.675-.101-.253-.446-1.268.099-2.64 0 0 .837-.269 2.742 1.021a9.582 9.582 0 0 1 2.496-.336 9.554 9.554 0 0 1 2.496.336c1.906-1.291 2.742-1.021 2.742-1.021.545 1.372.203 2.387.099 2.64.64.696 1.024 1.587 1.024 2.675 0 3.833-2.33 4.675-4.552 4.922.355.308.675.916.675 1.846 0 1.334-.012 2.41-.012 2.737 0 .267.178.577.687.479C19.146 20.115 22 16.379 22 11.974 22 6.465 17.535 2 12.026 2z",
            fill: "currentColor",
            fillRule: "evenodd"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 81,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
};
const MoonFilledIcon = ({ size = 24, width, height, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        "aria-hidden": "true",
        focusable: "false",
        height: size || height,
        role: "presentation",
        viewBox: "0 0 24 24",
        width: size || width,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
            d: "M21.53 15.93c-.16-.27-.61-.69-1.73-.49a8.46 8.46 0 01-1.88.13 8.409 8.409 0 01-5.91-2.82 8.068 8.068 0 01-1.44-8.66c.44-1.01.13-1.54-.09-1.76s-.77-.55-1.83-.11a10.318 10.318 0 00-6.32 10.21 10.475 10.475 0 007.04 8.99 10 10 0 002.89.55c.16.01.32.02.48.02a10.5 10.5 0 008.47-4.27c.67-.93.49-1.519.32-1.79z",
            fill: "currentColor"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 106,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 97,
        columnNumber: 3
    }, this);
const SunFilledIcon = ({ size = 24, width, height, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        "aria-hidden": "true",
        focusable: "false",
        height: size || height,
        role: "presentation",
        viewBox: "0 0 24 24",
        width: size || width,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("g", {
            fill: "currentColor",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                    d: "M19 12a7 7 0 11-7-7 7 7 0 017 7z"
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                    lineNumber: 129,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                    d: "M12 22.96a.969.969 0 01-1-.96v-.08a1 1 0 012 0 1.038 1.038 0 01-1 1.04zm7.14-2.82a1.024 1.024 0 01-.71-.29l-.13-.13a1 1 0 011.41-1.41l.13.13a1 1 0 010 1.41.984.984 0 01-.7.29zm-14.28 0a1.024 1.024 0 01-.71-.29 1 1 0 010-1.41l.13-.13a1 1 0 011.41 1.41l-.13.13a1 1 0 01-.7.29zM22 13h-.08a1 1 0 010-2 1.038 1.038 0 011.04 1 .969.969 0 01-.96 1zM2.08 13H2a1 1 0 010-2 1.038 1.038 0 011.04 1 .969.969 0 01-.96 1zm16.93-7.01a1.024 1.024 0 01-.71-.29 1 1 0 010-1.41l.13-.13a1 1 0 011.41 1.41l-.13.13a.984.984 0 01-.7.29zm-14.02 0a1.024 1.024 0 01-.71-.29l-.13-.14a1 1 0 011.41-1.41l.13.13a1 1 0 010 1.41.97.97 0 01-.7.3zM12 3.04a.969.969 0 01-1-.96V2a1 1 0 012 0 1.038 1.038 0 01-1 1.04z"
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                    lineNumber: 130,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 128,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 119,
        columnNumber: 3
    }, this);
const HeartFilledIcon = ({ size = 24, width, height, ...props })=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        "aria-hidden": "true",
        focusable: "false",
        height: size || height,
        role: "presentation",
        viewBox: "0 0 24 24",
        width: size || width,
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
            d: "M12.62 20.81c-.34.12-.9.12-1.24 0C8.48 19.82 2 15.69 2 8.69 2 5.6 4.49 3.1 7.56 3.1c1.82 0 3.43.88 4.44 2.24a5.53 5.53 0 0 1 4.44-2.24C19.51 3.1 22 5.6 22 8.69c0 7-6.48 11.13-9.38 12.12Z",
            fill: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 1.5
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
            lineNumber: 150,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 141,
        columnNumber: 3
    }, this);
const SearchIcon = (props)=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        "aria-hidden": "true",
        fill: "none",
        focusable: "false",
        height: "1em",
        role: "presentation",
        viewBox: "0 0 24 24",
        width: "1em",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                d: "M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z",
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                lineNumber: 171,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                d: "M22 22L20 20",
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                lineNumber: 178,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 161,
        columnNumber: 3
    }, this);
const NextUILogo = (props)=>{
    const { width, height = 40 } = props;
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("svg", {
        fill: "none",
        height: height,
        viewBox: "0 0 161 32",
        width: width,
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                className: "fill-black dark:fill-white",
                d: "M55.6827 5V26.6275H53.7794L41.1235 8.51665H40.9563V26.6275H39V5H40.89L53.5911 23.1323H53.7555V5H55.6827ZM67.4831 26.9663C66.1109 27.0019 64.7581 26.6329 63.5903 25.9044C62.4852 25.185 61.6054 24.1633 61.0537 22.9582C60.4354 21.5961 60.1298 20.1106 60.1598 18.6126C60.132 17.1113 60.4375 15.6228 61.0537 14.2563C61.5954 13.0511 62.4525 12.0179 63.5326 11.268C64.6166 10.5379 65.8958 10.16 67.1986 10.1852C68.0611 10.1837 68.9162 10.3468 69.7187 10.666C70.5398 10.9946 71.2829 11.4948 71.8992 12.1337C72.5764 12.8435 73.0985 13.6889 73.4318 14.6152C73.8311 15.7483 74.0226 16.9455 73.9968 18.1479V19.0773H63.2262V17.4194H72.0935C72.1083 16.4456 71.8952 15.4821 71.4714 14.6072C71.083 13.803 70.4874 13.1191 69.7472 12.6272C68.9887 12.1348 68.1022 11.8812 67.2006 11.8987C66.2411 11.8807 65.3005 12.1689 64.5128 12.7223C63.7332 13.2783 63.1083 14.0275 62.6984 14.8978C62.2582 15.8199 62.0314 16.831 62.0352 17.8546V18.8476C62.009 20.0078 62.2354 21.1595 62.6984 22.2217C63.1005 23.1349 63.7564 23.9108 64.5864 24.4554C65.4554 24.9973 66.4621 25.2717 67.4831 25.2448C68.1676 25.2588 68.848 25.1368 69.4859 24.8859C70.0301 24.6666 70.5242 24.3376 70.9382 23.919C71.3183 23.5345 71.6217 23.0799 71.8322 22.5799L73.5995 23.1604C73.3388 23.8697 72.9304 24.5143 72.4019 25.0506C71.8132 25.6529 71.1086 26.1269 70.3314 26.4434C69.4258 26.8068 68.4575 26.9846 67.4831 26.9663V26.9663ZM78.8233 10.4075L82.9655 17.325L87.1076 10.4075H89.2683L84.1008 18.5175L89.2683 26.6275H87.103L82.9608 19.9317L78.8193 26.6275H76.6647L81.7711 18.5169L76.6647 10.4062L78.8233 10.4075ZM99.5142 10.4075V12.0447H91.8413V10.4075H99.5142ZM94.2427 6.52397H96.1148V22.3931C96.086 22.9446 96.2051 23.4938 96.4597 23.9827C96.6652 24.344 96.9805 24.629 97.3589 24.7955C97.7328 24.9548 98.1349 25.0357 98.5407 25.0332C98.7508 25.0359 98.9607 25.02 99.168 24.9857C99.3422 24.954 99.4956 24.9205 99.6283 24.8853L100.026 26.5853C99.8062 26.6672 99.5805 26.7327 99.3511 26.7815C99.0274 26.847 98.6977 26.8771 98.3676 26.8712C97.6854 26.871 97.0119 26.7156 96.3973 26.4166C95.7683 26.1156 95.2317 25.6485 94.8442 25.0647C94.4214 24.4018 94.2097 23.6242 94.2374 22.8363L94.2427 6.52397ZM118.398 5H120.354V19.3204C120.376 20.7052 120.022 22.0697 119.328 23.2649C118.644 24.4235 117.658 25.3698 116.477 26.0001C115.168 26.6879 113.708 27.0311 112.232 26.9978C110.759 27.029 109.302 26.6835 107.996 25.9934C106.815 25.362 105.827 24.4161 105.141 23.2582C104.447 22.0651 104.092 20.7022 104.115 19.319V5H106.08V19.1831C106.061 20.2559 106.324 21.3147 106.843 22.2511C107.349 23.1459 108.094 23.8795 108.992 24.3683C109.993 24.9011 111.111 25.1664 112.242 25.139C113.373 25.1656 114.493 24.9003 115.495 24.3683C116.395 23.8815 117.14 23.1475 117.644 22.2511C118.16 21.3136 118.421 20.2553 118.402 19.1831L118.398 5ZM128 5V26.6275H126.041V5H128Z"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                lineNumber: 200,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                className: "fill-black dark:fill-white",
                d: "M23.5294 0H8.47059C3.79241 0 0 3.79241 0 8.47059V23.5294C0 28.2076 3.79241 32 8.47059 32H23.5294C28.2076 32 32 28.2076 32 23.5294V8.47059C32 3.79241 28.2076 0 23.5294 0Z"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                lineNumber: 204,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("path", {
                className: "fill-white dark:fill-black",
                d: "M17.5667 9.21729H18.8111V18.2403C18.8255 19.1128 18.6 19.9726 18.159 20.7256C17.7241 21.4555 17.0968 22.0518 16.3458 22.4491C15.5717 22.8683 14.6722 23.0779 13.6473 23.0779C12.627 23.0779 11.7286 22.8672 10.9521 22.4457C10.2007 22.0478 9.5727 21.4518 9.13602 20.7223C8.6948 19.9705 8.4692 19.1118 8.48396 18.2403V9.21729H9.72854V18.1538C9.71656 18.8298 9.88417 19.4968 10.2143 20.0868C10.5362 20.6506 11.0099 21.1129 11.5814 21.421C12.1689 21.7448 12.8576 21.9067 13.6475 21.9067C14.4374 21.9067 15.1272 21.7448 15.7169 21.421C16.2895 21.1142 16.7635 20.6516 17.0844 20.0868C17.4124 19.4961 17.5788 18.8293 17.5667 18.1538V9.21729ZM23.6753 9.21729V22.845H22.4309V9.21729H23.6753Z"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
                lineNumber: 208,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx",
        lineNumber: 192,
        columnNumber: 5
    }, this);
};

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "ThemeSwitch": ()=>ThemeSwitch
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__commonjs__external__react__ = __turbopack_external_require__("react", true);
var __TURBOPACK__esm__external__$40$react$2d$aria$2f$visually$2d$hidden__ = __turbopack_external_import__("@react-aria/visually-hidden");
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$switch__ = __turbopack_external_import__("@nextui-org/switch");
var __TURBOPACK__commonjs__external__next$2d$themes__ = __turbopack_external_require__("next-themes", true);
var __TURBOPACK__esm__external__clsx__ = __turbopack_external_import__("clsx");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$react$2d$aria$2f$visually$2d$hidden__,
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$switch__,
    __TURBOPACK__esm__external__clsx__
]);
[__TURBOPACK__esm__external__$40$react$2d$aria$2f$visually$2d$hidden__, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$switch__, __TURBOPACK__esm__external__clsx__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
const ThemeSwitch = ({ className, classNames })=>{
    const [isMounted, setIsMounted] = (0, __TURBOPACK__commonjs__external__react__["useState"])(false);
    const { theme, setTheme } = (0, __TURBOPACK__commonjs__external__next$2d$themes__["useTheme"])();
    const onChange = ()=>{
        theme === "light" ? setTheme("dark") : setTheme("light");
    };
    const { Component, slots, isSelected, getBaseProps, getInputProps, getWrapperProps } = (0, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$switch__["useSwitch"])({
        isSelected: theme === "light",
        onChange
    });
    (0, __TURBOPACK__commonjs__external__react__["useEffect"])(()=>{
        setIsMounted(true);
    }, [
        isMounted
    ]);
    // Prevent Hydration Mismatch
    if (!isMounted) return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("div", {
        className: "w-6 h-6"
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
        lineNumber: 43,
        columnNumber: 26
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(Component, {
        ...getBaseProps({
            className: (0, __TURBOPACK__esm__external__clsx__["default"])("px-px transition-opacity hover:opacity-80 cursor-pointer", className, classNames?.base)
        }),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$react$2d$aria$2f$visually$2d$hidden__["VisuallyHidden"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("input", {
                    ...getInputProps()
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
                lineNumber: 55,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("div", {
                ...getWrapperProps(),
                className: slots.wrapper({
                    class: (0, __TURBOPACK__esm__external__clsx__["default"])([
                        "w-auto h-auto",
                        "bg-transparent",
                        "rounded-lg",
                        "flex items-center justify-center",
                        "group-data-[selected=true]:bg-transparent",
                        "!text-default-500",
                        "pt-px",
                        "px-0",
                        "mx-0"
                    ], classNames?.wrapper)
                }),
                children: isSelected ? /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["MoonFilledIcon"], {
                    size: 22
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
                    lineNumber: 78,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["SunFilledIcon"], {
                    size: 22
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
                    lineNumber: 80,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
};
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "Navbar": ()=>Navbar
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__ = __turbopack_external_import__("@nextui-org/navbar");
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$button__ = __turbopack_external_import__("@nextui-org/button");
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$kbd__ = __turbopack_external_import__("@nextui-org/kbd");
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__ = __turbopack_external_import__("@nextui-org/link");
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$input__ = __turbopack_external_import__("@nextui-org/input");
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$theme__ = __turbopack_external_import__("@nextui-org/theme");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/link.js [ssr] (ecmascript)");
var __TURBOPACK__esm__external__clsx__ = __turbopack_external_import__("clsx");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/site.ts [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$theme$2d$switch$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/theme-switch.tsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/icons.tsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__,
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$button__,
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$kbd__,
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__,
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$input__,
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$theme__,
    __TURBOPACK__esm__external__clsx__,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$theme$2d$switch$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$button__, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$kbd__, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$input__, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$theme__, __TURBOPACK__esm__external__clsx__, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$theme$2d$switch$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
;
;
;
;
const Navbar = ()=>{
    const searchInput = /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$input__["Input"], {
        "aria-label": "Search",
        classNames: {
            inputWrapper: "bg-default-100",
            input: "text-sm"
        },
        endContent: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$kbd__["Kbd"], {
            className: "hidden lg:inline-block",
            keys: [
                "command"
            ],
            children: "K"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
            lineNumber: 38,
            columnNumber: 9
        }, void 0),
        labelPlacement: "outside",
        placeholder: "Search...",
        startContent: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["SearchIcon"], {
            className: "text-base text-default-400 pointer-events-none flex-shrink-0"
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
            lineNumber: 45,
            columnNumber: 9
        }, void 0),
        type: "search"
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["Navbar"], {
        maxWidth: "xl",
        position: "sticky",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarContent"], {
                className: "basis-1/5 sm:basis-full",
                justify: "start",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarBrand"], {
                        className: "gap-3 max-w-fit",
                        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                            className: "flex justify-start items-center gap-1",
                            href: "/",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["Logo"], {}, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("p", {
                                    className: "font-bold text-inherit",
                                    children: "ACME"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 57,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("div", {
                        className: "hidden lg:flex gap-4 justify-start ml-2",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].navItems.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarItem"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$link$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    className: (0, __TURBOPACK__esm__external__clsx__["default"])((0, __TURBOPACK__esm__external__$40$nextui$2d$org$2f$theme__["link"])({
                                        color: "foreground"
                                    }), "data-[active=true]:text-primary data-[active=true]:font-medium"),
                                    color: "foreground",
                                    href: item.href,
                                    children: item.label
                                }, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 63,
                                    columnNumber: 15
                                }, this)
                            }, item.href, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 62,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarContent"], {
                className: "hidden sm:flex basis-1/5 sm:basis-full",
                justify: "end",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarItem"], {
                        className: "hidden sm:flex gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__["Link"], {
                                isExternal: true,
                                href: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].links.twitter,
                                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["TwitterIcon"], {
                                    className: "text-default-500"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 84,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 83,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__["Link"], {
                                isExternal: true,
                                href: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].links.discord,
                                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["DiscordIcon"], {
                                    className: "text-default-500"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 87,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 86,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__["Link"], {
                                isExternal: true,
                                href: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].links.github,
                                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["GithubIcon"], {
                                    className: "text-default-500"
                                }, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 90,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$theme$2d$switch$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["ThemeSwitch"], {}, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 92,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarItem"], {
                        className: "hidden lg:flex",
                        children: searchInput
                    }, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 94,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarItem"], {
                        className: "hidden md:flex",
                        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$button__["Button"], {
                            isExternal: true,
                            as: __TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__["Link"],
                            className: "text-sm font-normal text-default-600 bg-default-100",
                            href: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].links.sponsor,
                            startContent: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["HeartFilledIcon"], {
                                className: "text-danger"
                            }, void 0, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 101,
                                columnNumber: 27
                            }, void 0),
                            variant: "flat",
                            children: "Sponsor"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 95,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                lineNumber: 78,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarContent"], {
                className: "sm:hidden basis-1 pl-4",
                justify: "end",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__["Link"], {
                        isExternal: true,
                        href: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].links.github,
                        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$icons$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["GithubIcon"], {
                            className: "text-default-500"
                        }, void 0, false, {
                            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                            lineNumber: 111,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 110,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$theme$2d$switch$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["ThemeSwitch"], {}, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 113,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarMenuToggle"], {}, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 114,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarMenu"], {
                children: [
                    searchInput,
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("div", {
                        className: "mx-4 mt-2 flex flex-col gap-2",
                        children: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].navMenuItems.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$navbar__["NavbarMenuItem"], {
                                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$link__["Link"], {
                                    color: index === 2 ? "primary" : index === __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$site$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["siteConfig"].navMenuItems.length - 1 ? "danger" : "foreground",
                                    href: "#",
                                    size: "lg",
                                    children: item.label
                                }, void 0, false, {
                                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                    lineNumber: 122,
                                    columnNumber: 15
                                }, this)
                            }, `${item}-${index}`, false, {
                                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                                lineNumber: 121,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                        lineNumber: 119,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
};
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": ()=>DefaultLayout
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$layouts$2f$head$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/head.tsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$navbar$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/navbar.tsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$navbar$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$navbar$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
function DefaultLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("div", {
        className: "relative flex flex-col h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$layouts$2f$head$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["Head"], {}, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$navbar$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["Navbar"], {}, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("main", {
                className: "container mx-auto max-w-7xl px-6 flex-grow pt-16",
                children: children
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("footer", {
                className: "w-full flex items-center justify-center py-3"
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/index.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": ()=>IndexPage
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$CryptoTable$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/components/CryptoTable.tsx [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$layouts$2f$default$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/layouts/default.tsx [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$CryptoTable$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$layouts$2f$default$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$CryptoTable$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$layouts$2f$default$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
function IndexPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$layouts$2f$default$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("div", {
            style: {
                border: '1px solid red'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("h1", {
                    children: "Real-time Price Data"
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/index.tsx",
                    lineNumber: 9,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$components$2f$CryptoTable$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/index.tsx",
                    lineNumber: 10,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/index.tsx",
            lineNumber: 8,
            columnNumber: 5
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/index.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__c0516f._.js.map