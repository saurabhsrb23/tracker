module.exports = {

"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>Document
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/document.js [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
function Document() {
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Html"], {
        lang: "en",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Head"], {}, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                lineNumber: 6,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])("body", {
                className: "min-h-screen bg-background font-sans antialiased",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["Main"], {}, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                        lineNumber: 8,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$document$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["NextScript"], {}, void 0, false, {
                        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                        lineNumber: 9,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
                lineNumber: 7,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}

})()),
"[next]/internal/font/google/inter_b35c0a41.module.css [ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "inter_b35c0a41-module__Y0D1la__className",
  "variable": "inter_b35c0a41-module__Y0D1la__variable",
});

})()),
"[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.module.css [ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__Inter_b35c0a', '__Inter_Fallback_b35c0a'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[next]/internal/font/google/fira_code_b79a8a20.module.css [ssr] (css module)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {

__turbopack_export_value__({
  "className": "fira_code_b79a8a20-module__-fm2dq__className",
  "variable": "fira_code_b79a8a20-module__-fm2dq__variable",
});

})()),
"[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.module.css [ssr] (css module)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'__Fira_Code_b79a8a', '__Fira_Code_Fallback_b79a8a'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$module$2e$css__$5b$ssr$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <locals>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
;
;
;
;

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <module evaluation>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$fonts$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <locals>");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript) <export default as fontSans>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "fontSans": ()=>__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript) <export default as fontMono>": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "fontMono": ()=>__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
});
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";

})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/slices/cryptoSlice.ts [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "clearCryptoData": ()=>clearCryptoData,
    "default": ()=>__TURBOPACK__default__export__,
    "fetchCryptoFailure": ()=>fetchCryptoFailure,
    "fetchCryptoStart": ()=>fetchCryptoStart,
    "fetchCryptoSuccess": ()=>fetchCryptoSuccess
});
var __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__ = __turbopack_external_import__("@reduxjs/toolkit");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__
]);
[__TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
const initialState = {
    data: [],
    status: 'idle',
    error: null
};
const cryptoSlice = (0, __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__["createSlice"])({
    name: 'crypto',
    initialState,
    reducers: {
        fetchCryptoStart (state) {
            state.status = 'loading';
        },
        fetchCryptoSuccess (state, action) {
            state.data = action.payload;
            state.status = 'succeeded';
            state.error = null;
        },
        fetchCryptoFailure (state, action) {
            state.status = 'failed';
            state.error = action.payload;
        },
        clearCryptoData (state) {
            state.data = [];
            state.status = 'idle';
            state.error = null;
        }
    }
});
const { fetchCryptoStart, fetchCryptoSuccess, fetchCryptoFailure, clearCryptoData } = cryptoSlice.actions;
const __TURBOPACK__default__export__ = cryptoSlice.reducer;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/store.ts [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "wrapper": ()=>wrapper
});
var __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__ = __turbopack_external_import__("@reduxjs/toolkit");
var __TURBOPACK__commonjs__external__next$2d$redux$2d$wrapper__ = __turbopack_external_require__("next-redux-wrapper", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$slices$2f$cryptoSlice$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/slices/cryptoSlice.ts [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$slices$2f$cryptoSlice$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$slices$2f$cryptoSlice$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
const makeStore = ()=>(0, __TURBOPACK__esm__external__$40$reduxjs$2f$toolkit__["configureStore"])({
        reducer: {
            crypto: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$slices$2f$cryptoSlice$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
        },
        devTools: ("TURBOPACK compile-time value", "development") !== 'production'
    });
const wrapper = (0, __TURBOPACK__commonjs__external__next$2d$redux$2d$wrapper__["createWrapper"])(makeStore);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),
"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx [ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, a: __turbopack_async_module__, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_esm__({
    "default": ()=>__TURBOPACK__default__export__,
    "fonts": ()=>fonts
});
var __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__ = __turbopack_external_require__("react/jsx-dev-runtime", true);
var __TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__ = __turbopack_external_import__("@nextui-org/system");
var __TURBOPACK__commonjs__external__next$2d$themes__ = __turbopack_external_require__("next-themes", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/router.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$config$2f$fonts$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/config/fonts.ts [ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontSans$3e$__ = __turbopack_import__("[next]/internal/font/google/inter_b35c0a41.js [ssr] (ecmascript) <export default as fontSans>");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontMono$3e$__ = __turbopack_import__("[next]/internal/font/google/fira_code_b79a8a20.js [ssr] (ecmascript) <export default as fontMono>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/redux/store.ts [ssr] (ecmascript)");
var __TURBOPACK__esm__external__react$2d$redux__ = __turbopack_external_import__("react-redux");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__,
    __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__esm__external__react$2d$redux__
]);
[__TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__esm__external__react$2d$redux__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
;
;
;
function App({ Component, pageProps }) {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$node_modules$2f$next$2f$router$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__$40$nextui$2d$org$2f$system__["NextUIProvider"], {
        navigate: router.push,
        children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__commonjs__external__next$2d$themes__["ThemeProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(__TURBOPACK__esm__external__react$2d$redux__["Provider"], {
                store: __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["wrapper"].useWrappedStore(pageProps).store,
                children: /*#__PURE__*/ (0, __TURBOPACK__commonjs__external__react$2f$jsx$2d$dev$2d$runtime__["jsxDEV"])(Component, {
                    ...pageProps
                }, void 0, false, {
                    fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
                lineNumber: 18,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
const fonts = {
    sans: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_b35c0a41$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontSans$3e$__["fontSans"].style.fontFamily,
    mono: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$fira_code_b79a8a20$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fontMono$3e$__["fontMono"].style.fontFamily
};
const __TURBOPACK__default__export__ = __TURBOPACK__imported__module__$5b$project$5d2f$Documents$2f$Next$2e$js$2f$stock$2f$crypto$2d$price$2d$tracker$2f$crypto_price_tracker$2f$redux$2f$store$2e$ts__$5b$ssr$5d$__$28$ecmascript$29$__["wrapper"].withRedux(App);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);
})()),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__b939e5._.js.map