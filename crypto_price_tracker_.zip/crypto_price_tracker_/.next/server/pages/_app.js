const CHUNK_PUBLIC_PATH = "server/pages/_app.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_9fcdb1._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__02d705._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__3efd65._.css");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
