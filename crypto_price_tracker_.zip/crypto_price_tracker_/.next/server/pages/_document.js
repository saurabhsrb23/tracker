const CHUNK_PUBLIC_PATH = "server/pages/_document.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/fc95d_Documents_Next_js_stock_crypto-price-tracker_crypto_price_tracker_cadd76._.js");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
