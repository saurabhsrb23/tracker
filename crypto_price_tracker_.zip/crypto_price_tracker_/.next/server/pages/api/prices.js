const CHUNK_PUBLIC_PATH = "server/pages/api/prices.js";
const runtime = require("../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/fc95d_Documents_Next_js_stock_crypto-price-tracker_crypto_price_tracker_b35159._.js");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/api/prices.ts [api] (ecmascript)\" } [api] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
