const CHUNK_PUBLIC_PATH = "server/pages/pricing.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_bc40da._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__80142d._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__3efd65._.css");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/pricing/index.tsx [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_document.tsx [ssr] (ecmascript)\", INNER_APP => \"[project]/Documents/Next.js/stock/crypto-price-tracker/crypto_price_tracker/pages/_app.tsx [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
