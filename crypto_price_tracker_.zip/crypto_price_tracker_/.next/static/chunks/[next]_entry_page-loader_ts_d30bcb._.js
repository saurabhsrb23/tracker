(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[next]_entry_page-loader_ts_cef13d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[next]_entry_page-loader_ts_cef13d._.js",
  "chunks": [
    "static/chunks/[root of the server]__6d5dc0._.js",
    "static/chunks/node_modules_next_f5c602._.js",
    "static/chunks/node_modules_react_1936df._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_aa3192.js",
    "static/chunks/node_modules_react-dom_638446._.js",
    "static/chunks/node_modules_axios_lib_f94547._.js",
    "static/chunks/node_modules_mongoose_dist_browser_umd_fc868f.js",
    "static/chunks/node_modules_framer-motion_dist_es_d971f9._.js",
    "static/chunks/node_modules_@react-aria_5fbab2._.js",
    "static/chunks/node_modules_@react-aria_1357b7._.js",
    "static/chunks/node_modules_tailwind-merge_dist_lib_aa0c54._.js",
    "static/chunks/node_modules_@nextui-org_react-rsc-utils_dist_26a3ea._.js",
    "static/chunks/node_modules_408fa5._.js",
    "static/chunks/node_modules_next_dist_pages_df9696._.js"
  ],
  "source": "entry"
});
