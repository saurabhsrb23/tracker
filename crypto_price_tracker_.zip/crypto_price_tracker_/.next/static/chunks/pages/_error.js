__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root of the server]__87ce21._.js",
  "static/chunks/node_modules_react_7dfddb._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_aa3192.js",
  "static/chunks/node_modules_react-dom_638446._.js",
  "static/chunks/node_modules_853db3._.js",
  "static/chunks/[turbopack]_dev_client_38d6c6._.js",
  "static/chunks/node_modules_next_dist_pages_bf9e68._.js",
  "static/chunks/[next]_entry_page-loader_ts_4ae82c._.js",
  "static/chunks/[next]_entry_page-loader_ts_ef03c0._.js"
])
