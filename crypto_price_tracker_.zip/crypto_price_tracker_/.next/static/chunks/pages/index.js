__turbopack_load_page_chunks__("/", [
  "static/chunks/[root of the server]__31c17a._.js",
  "static/chunks/node_modules_next_07e3c2._.js",
  "static/chunks/node_modules_react_1936df._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_aa3192.js",
  "static/chunks/node_modules_react-dom_638446._.js",
  "static/chunks/node_modules_framer-motion_dist_es_d971f9._.js",
  "static/chunks/node_modules_@react-aria_5fbab2._.js",
  "static/chunks/node_modules_@react-aria_1357b7._.js",
  "static/chunks/node_modules_tailwind-merge_dist_lib_aa0c54._.js",
  "static/chunks/node_modules_@nextui-org_react-rsc-utils_dist_26a3ea._.js",
  "static/chunks/node_modules_408fa5._.js",
  "static/chunks/node_modules_next_dist_pages_df9696._.js",
  "static/chunks/[next]_entry_page-loader_ts_aa57ee._.js",
  "static/chunks/[next]_entry_page-loader_ts_8d8ae4._.js"
])
