__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_995787._.js",
  "static/chunks/node_modules_react_1936df._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_aa3192.js",
  "static/chunks/node_modules_react-dom_638446._.js",
  "static/chunks/node_modules_da2fe5._.js",
  "static/chunks/[root of the server]__45e61d._.js",
  "static/chunks/[root of the server]__77c942._.css",
  "static/chunks/node_modules_next_dist_pages_82100a._.js",
  "static/chunks/[next]_entry_page-loader_ts_287fbe._.js",
  "static/chunks/[next]_entry_page-loader_ts_206ba7._.js"
])
