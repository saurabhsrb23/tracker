(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[next]_entry_page-loader_ts_430693._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[next]_entry_page-loader_ts_430693._.js",
  "chunks": [
    "static/chunks/[root of the server]__065dea._.js",
    "static/chunks/node_modules_next_07e3c2._.js",
    "static/chunks/node_modules_react_1936df._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_aa3192.js",
    "static/chunks/node_modules_react-dom_638446._.js",
    "static/chunks/node_modules_@nextui-org_theme_dist_10a0aa._.js",
    "static/chunks/node_modules_tailwind-merge_dist_lib_aa0c54._.js",
    "static/chunks/node_modules_@react-aria_63e5ea._.js",
    "static/chunks/node_modules_@react-aria_b30f58._.js",
    "static/chunks/node_modules_@nextui-org_react-rsc-utils_dist_d8861a._.js",
    "static/chunks/node_modules_framer-motion_dist_es_08feb6._.js",
    "static/chunks/node_modules_ac6b9b._.js",
    "static/chunks/node_modules_next_dist_pages_29f2ad._.js"
  ],
  "source": "entry"
});
