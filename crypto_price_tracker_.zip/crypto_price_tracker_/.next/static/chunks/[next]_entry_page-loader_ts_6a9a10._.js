(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[next]_entry_page-loader_ts_6a9a10._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[next]_entry_page-loader_ts_6a9a10._.js",
  "chunks": [
    "static/chunks/node_modules_next_995787._.js",
    "static/chunks/node_modules_react_1936df._.js",
    "static/chunks/node_modules_react-dom_cjs_react-dom_development_aa3192.js",
    "static/chunks/node_modules_react-dom_638446._.js",
    "static/chunks/node_modules_9ac0ef._.js",
    "static/chunks/[root of the server]__46fb55._.js",
    "static/chunks/[root of the server]__77c942._.css",
    "static/chunks/node_modules_next_dist_pages_8ca461._.js"
  ],
  "source": "entry"
});
