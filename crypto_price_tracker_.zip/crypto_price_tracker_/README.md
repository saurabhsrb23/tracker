# Real-time Price Tracker

This project is a real-time price tracker for stocks or cryptocurrencies using Next.js, TypeScript, Redux, and MongoDB.

## Installation

1. Clone the repository:
    ```bash
    git clone https://github.com/your-username/price-tracker.git
    cd price-tracker
    ```

2. Install dependencies:
    ```bash
    npm install
    ```

3. Setup environment variables:
    Create a `.env.local` file at the root of your project with the following content:
    ```env
    MONGODB_URI=your-mongodb-connection-string
    ```

4. Run the development server:
    ```bash
    npm run dev
    ```

## Usage

- The project will fetch real-time price data for stocks or cryptocurrencies every few seconds and store it in a MongoDB database.
- The frontend will display the most recent 20 real-time data entries in a dynamic table that updates in real-time.

## Technologies Used

- Next.js
- TypeScript
- Redux
- MongoDB
- Axios

## Contributing

Feel free to submit issues and pull requests.

## License

MIT License
